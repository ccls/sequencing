library(EBSeq)
# 3.1
data(GeneMat)
str(GeneMat)
Sizes=MedianNorm(GeneMat)
EBOut=EBTest(Data=GeneMat,
			 Conditions=as.factor(rep(c("C1","C2"),each=5)),sizeFactors=Sizes, maxround=5)
PP=GetPPMat(EBOut)
str(PP)
head(PP)
DEfound=rownames(PP)[which(PP[,"PPDE"]>=.95)]
str(DEfound)
#3.2
data(IsoList)
str(IsoList)
IsoMat=IsoList$IsoMat
str(IsoMat)
IsoNames=IsoList$IsoNames
IsosGeneNames=IsoList$IsosGeneNames
IsoSizes=MedianNorm(IsoMat)
NgList=GetNg(IsoNames, IsosGeneNames)
IsoNgTrun=NgList$IsoformNgTrun
IsoNgTrun[c(1:3,1001:1003,3001:3003)]
IsoEBOut=EBTest(Data=IsoMat, NgVector=IsoNgTrun,
				Conditions=as.factor(rep(c("C1","C2"),each=5)),sizeFactors=IsoSizes, maxround=5)
IsoPP=GetPPMat(IsoEBOut)
str(IsoPP)
head(IsoPP)
IsoDE=rownames(IsoPP)[which(IsoPP[,"PPDE"]>=.95)]
str(IsoDE)
#3.3
data(MultiGeneMat)
str(MultiGeneMat)
Conditions=c("C1","C1","C2","C2","C3","C3")
PosParti=GetPatterns(Conditions)
PosParti
Parti=PosParti[-3,]
Parti
MultiSize=MedianNorm(MultiGeneMat)
MultiOut=EBMultiTest(MultiGeneMat,NgVector=NULL,Conditions=Conditions,
					            AllParti=Parti, sizeFactors=MultiSize, maxround=5)
MultiPP=GetMultiPP(MultiOut)
names(MultiPP)
MultiPP$PP[1:10,]
MultiPP$MAP[1:10]
MultiPP$Patterns
#4.1
set.seed(13)
GeneGenerate=GeneSimu(DVDconstant=4, DVDqt1=NULL, DVDqt2=NULL,
					  Conditions=rep(c("C1","C2"),each=5), NumofSample=10, NumofGene=10000,
					  DEGeneProp=.1, Phiconstant=NULL, Phi.qt1=.1, Phi.qt2=.9,
					  Meanconstant=NULL, OnlyData=T)
GeneData=GeneGenerate$data
GeneTrueDENames=GeneGenerate$TrueDE
str(GeneData)
str(GeneTrueDENames)
Sizes=MedianNorm(GeneData)
EBOut=EBTest(Data=GeneData,
			 Conditions=as.factor(rep(c("C1","C2"),each=5)),sizeFactors=Sizes, maxround=5)
PP=GetPPMat(EBOut)
str(PP)
head(PP)
DEfound=rownames(PP)[which(PP[,"PPDE"]>=.95)]
str(DEfound)
sum(DEfound%in%GeneTrueDENames)
EBOut$Alpha
EBOut$Beta
EBOut$P
par(mfrow=c(2,2))
QQP(EBOut, name="Gene Simulation")
par(mfrow=c(2,2))
DenNHist(EBOut,name="Gene Simulation")

#4.2
set.seed(13)
IsoGenerate=IsoSimu(DVDconstant=NULL, DVDqt1=.97, DVDqt2=.98,
					Conditions=as.factor(rep(c("C1","C2"),each=5)), NumofSample=10,
					NumofIso=c(1000,2000,3000), DEIsoProp=.1, Phiconstant=NULL,
					Phi.qt1=.25, Phi.qt2=.75, OnlyData=T )
str(IsoGenerate)
IsoMat=do.call(rbind,IsoGenerate$data)
str(IsoMat)
IsoNames=rownames(IsoMat)
str(IsoNames)
GeneNames=paste("Gene",c(1:3000),sep="_")
IsosGeneNames=c(GeneNames[1:1000],rep(GeneNames[1001:2000],each=2),
				rep(GeneNames[2001:3000],each=3))
NgList=GetNg(IsoNames, IsosGeneNames, TrunThre=3)
names(NgList)
IsoNgTrun=NgList$IsoformNgTrun
IsoNgTrun[c(1:3,1001:1003,3001:3003)]
IsoSizes=MedianNorm(IsoMat)
IsoEBOut=EBTest(Data=IsoMat, NgVector=IsoNgTrun,
				Conditions=as.factor(rep(c("C1","C2"),each=5)),sizeFactors=IsoSizes, maxround=5)
IsoPP=GetPPMat(IsoEBOut)
str(IsoPP)
IsoDE=rownames(IsoPP)[which(IsoPP[,"PPDE"]>=.95)]
str(IsoDE)
sum(IsoDE%in%IsoGenerate$TrueDE)
IsoEBOut$Alpha
IsoEBOut$Beta
IsoEBOut$P
par(mfrow=c(2,2))
PolyFitValue=vector("list",3)
for(i in 1:3)
	          PolyFitValue[[i]]=PolyFitPlot(IsoEBOut$C1Mean[[i]],
											                IsoEBOut$C1EstVar[[i]],5)
PolyAll=PolyFitPlot(unlist(IsoEBOut$C1Mean), unlist(IsoEBOut$C1EstVar),5)
lines(log10(IsoEBOut$C1Mean[[1]][PolyFitValue[[1]]$sort]),
	  PolyFitValue[[1]]$fit[PolyFitValue[[1]]$sort],col="yellow",lwd=2)
lines(log10(IsoEBOut$C1Mean[[2]][PolyFitValue[[2]]$sort]),
	  PolyFitValue[[2]]$fit[PolyFitValue[[2]]$sort],col="pink",lwd=2)
lines(log10(IsoEBOut$C1Mean[[3]][PolyFitValue[[3]]$sort]),
	  PolyFitValue[[3]]$fit[PolyFitValue[[3]]$sort],col="green",lwd=2)
legend("topleft",c("All Isoforms","Ng = 1","Ng = 2","Ng = 3"),
	   col=c("red","yellow","pink","green"),lty=1,lwd=3,box.lwd=2)
par(mfrow=c(2,3))
QQP(IsoEBOut,
	name="Isoforms",  GroupName=paste("Ng = ",c(1:3),sep=""))
par(mfrow=c(2,3))
DenNHist(IsoEBOut,
		 name="Isoforms",  GroupName=paste("Ng = ",c(1:3),sep=""))
#4.3
Conditions=c("C1","C1","C2","C2","C3","C3")
PosParti=GetPatterns(Conditions)
PosParti
PlotPattern(PosParti)
Parti=PosParti[-3,]
Parti
set.seed(13)
MultiData=GeneMultiSimu(Conditions=Conditions,AllParti=Parti,
						          NumofSample=6,NumofGene=1000,DEGeneProp=c(.7,.1,.1,.1),
								            DVDqt1=.98,DVDqt2=.99,Phi.qt1=.25,Phi.qt2=.75)
str(MultiData)
MultiSize=MedianNorm(MultiData$data)
MultiOut=EBMultiTest(MultiData$data,NgVector=NULL,Conditions=Conditions,
					            AllParti=Parti, sizeFactors=MultiSize, maxround=5)
MultiPP=GetMultiPP(MultiOut)
names(MultiPP)
MultiPP$PP[1:10,]
MultiPP$MAP[1:10]
MultiPP$Patterns
sum(MultiPP$MAP==MultiData$Patterns)

# EOF
