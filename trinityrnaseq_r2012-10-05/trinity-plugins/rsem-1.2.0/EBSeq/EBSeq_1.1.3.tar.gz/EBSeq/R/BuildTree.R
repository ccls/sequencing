

BuildTree=function(GeneMat,Update=T,maxround=5,Firstpool=2,Print=F, VarFromOpt=T){
# IterWithin may not work!
NumSample=ncol(GeneMat)
Cor2=cor(GeneMat,method="spearman")
Cor2=Cor2-diag(ncol(Cor2))

CorSum=colSums(Cor2)
Start=names(CorSum)[which.max(CorSum)]
Start2=names(CorSum)[which(rank(Cor2[Start,])==NumSample)]
if(Firstpool>2)Start3=names(CorSum)[which(rank(Cor2[Start,])==c((NumSample-Firstpool+2):(NumSample-1)))]
if(Firstpool==2)Start3=NULL
Sizes=MedianNorm(GeneMat)

if(Firstpool>2)Cond=factor(c(1,1,rep(2,Firstpool-2)))
if(Firstpool==2)Cond=factor(1:2)
EBStart=EBTest(cbind(GeneMat[,c(Start,Start2)],GeneMat[,Start3])
,sizeFactors=Sizes[c(Start,Start2,Start3)],
Conditions=Cond,maxround=maxround)
AlphaIn=EBStart[[1]][maxround]
BetaIn=EBStart[[2]][maxround]
RIn=EBStart[[7]][[1]]

Seq=names(CorSum)
NameList=as.list(Seq)
In=1:length(Seq)


OptDist=rep(NULL,(NumSample-1))
OptTerm=vector("list",(NumSample-1))
i=1
while(i <= (NumSample-1)){
	AllPosi=combn(In,2)
	Dist=sapply(1:ncol(AllPosi),function(j){
				Name1=NameList[[AllPosi[1,j]]]
				Name2=NameList[[AllPosi[2,j]]]
				cat(paste(j," "))
	EBTest(cbind(GeneMat[,Name1],GeneMat[,Name2])
		               ,sizeFactors=Sizes[c(Name1,Name2)],
					   Conditions=factor(c(rep(1,length(Name1)),rep(2,length(Name2))))
					   ,maxround=maxround,Alpha=AlphaIn, Beta=BetaIn,RInput=RIn,Print=F)$P[maxround]
})
	
	WhichMin=which.min(Dist)
	OptDist[i]=Dist[WhichMin]
	IdxMin=AllPosi[,WhichMin]
	In=In[!In%in%IdxMin]
	CB=unlist(NameList[IdxMin])
	CBLen=length(CB)
	NameList=c(NameList,list(CB))
	In=c(In,length(NameList))
	OptTerm[[i]]=CB

	EachTerm=sapply(1:ncol(AllPosi),function(m)length(unlist(NameList[AllPosi[,m]])))
	MaxNum=which.max(EachTerm)
	if(CBLen==max(EachTerm)| VarFromOpt==T)OfInt=IdxMin
	if(CBLen<max(EachTerm) & VarFromOpt==F)OfInt=AllPosi[,MaxNum]

	if(Update==T){
	Name1=NameList[[OfInt[1]]]
	Name2=NameList[[OfInt[2]]]
		EBUp=EBTest(cbind(GeneMat[,Name1],GeneMat[,Name2])
	,sizeFactors=Sizes[c(Name1,Name2)],
	Conditions=factor(c(1,2)),maxround=maxround)
	AlphaIn=EBUp[[1]][maxround]
	BetaIn=EBUp[[2]][maxround]
	RIn=EBUp[[7]][[1]]
	}

	i=i+1
}
Output=list(OptDist=OptDist,OptTerm=OptTerm,
			Alpha=AlphaIn,Beta=BetaIn,R=RIn,Sizes=Sizes)
}














