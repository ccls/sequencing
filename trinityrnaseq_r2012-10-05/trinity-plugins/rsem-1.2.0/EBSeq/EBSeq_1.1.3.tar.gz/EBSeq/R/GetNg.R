GetNg<- function(IsoformName, GeneName, TrunThre=3){
	GeneNg = tapply(IsoformName, GeneName, length)
	IsoformNg = GeneNg[GeneName]
	names(IsoformNg) = IsoformName
	GeneNgTrun=GeneNg
	GeneNgTrun[GeneNgTrun>TrunThre]=TrunThre
	IsoformNgTrun=IsoformNg
	IsoformNgTrun[IsoformNgTrun>TrunThre]=TrunThre
	out=list( GeneNg=GeneNg, GeneNgTrun=GeneNgTrun, IsoformNg=IsoformNg, IsoformNgTrun=IsoformNgTrun)
	}
