GetMultiFC=function(EBOut,SmallNum=.01){
	NumNgGroup=length(EBOut$DataList)
	OutNames=rownames(EBOut$PPMat)
	NumCondition=length(EBOut$SPMean[[1]])
	ConditionNames=colnames(EBOut$AllParti)
	if(NumNgGroup>1)
	CondMeans=sapply(1:NumNgGroup,function(i)unlist(sapply(EBOut$SPMean,function(j)j[[i]]))[OutNames])
	else {
		CondMeanstmp=do.call(cbind,EBOut$SPMean[[1]])
		CondMeans=CondMeanstmp[OutNames,]}
	colnames(CondMeans)=ConditionNames
	CondMeansPlus=CondMeans+SmallNum

	FCMat=matrix(0,ncol=choose(NumCondition,2),nrow=length(OutNames))
	rownames(FCMat)=OutNames
	k=1
	ColNames=rep(NA,choose(NumCondition,2))
	for(i in 1:(NumCondition-1)){
		for(j in (i+1):NumCondition)
		{
		ColNames[k]=paste(ConditionNames[i],"Over",ConditionNames[j],sep="")
		FCMat[,k]=CondMeansPlus[,i]/CondMeansPlus[,j]
		k=k+1
		}
	}
	colnames(FCMat)=ColNames
	Log2FCMat=log2(FCMat)
	Out=list(FCMat=FCMat,Log2FCMat=Log2FCMat,CondMeans=CondMeans)
}

