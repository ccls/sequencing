QQP <-
function(EBOut,name=NULL,AList="F",GroupName=NULL){
    maxround=nrow(EBOut$Alpha)
	AlphaResult=EBOut$Alpha[maxround,]
    BetaResult=EBOut$Beta[maxround,]
	    for(con in 1:2){
		    if(con==1)QList=EBOut$QList1
		    if(con==2)QList=EBOut$QList2
		    for (i in 1:length(BetaResult)){
				tmpSize=length(QList[[i]][QList[[i]]<1 & !is.na(QList[[i]])])
			if (AList=="F") rdpts=rbeta(tmpSize,AlphaResult,BetaResult[i])
				else rdpts=rbeta(tmpSize,AlphaResult[i],BetaResult[i])
	qqplot(QList[[i]][QList[[i]]<1], 
		   rdpts,xlab="estimated q's", ylab="simulated q's from fitted beta",
		   main=paste(GroupName[i]," ",name," C",con,sep=""),
		   xlim=c(0,1),ylim=c(0,1))
	fit=lm(sort(rdpts)~sort(QList[[i]][QList[[i]]<1  & !is.na(QList[[i]])]))
	abline(fit,col="red")
	
		}}
}

